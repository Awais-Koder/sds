<?php

namespace App\Filament\Resources\SubmittelResource\Pages;

use App\Filament\Resources\SubmittelResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewSubmittel extends ViewRecord
{
    protected static string $resource = SubmittelResource::class;
}
